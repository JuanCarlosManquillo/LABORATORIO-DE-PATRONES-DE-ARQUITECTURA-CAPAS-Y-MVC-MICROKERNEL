/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.com.hyunseda.market.service;

import infra.Subject;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Juan
 */
public class Carrito {
    private List<Product> productosTienda;
    private List<Product> productosEnCarrito;
    
    public Carrito(){
        this.productosTienda=new ArrayList<>();
        this.productosEnCarrito=new ArrayList<>();
    }

    public List<Product> getProductosTienda() {
        return productosTienda;
    }

    public void setProductosTienda(List<Product> productosTienda) {
        this.productosTienda = productosTienda;
      
    }

    public List<Product> getProductosEnCarrito() {
        return productosEnCarrito;
    }

    public void setProductosEnCarrito(List<Product> productosEnCarrito) {
        this.productosEnCarrito = productosEnCarrito;
        //this.notifyAllObserves();
    }
    
    public void agregarProductoTienda(Product producto){
        productosTienda.add(producto);
    }
    
    public void agregarProductoCarrito(Product producto){
        productosEnCarrito.add(producto);
    }
    public void eliminarProductodelCarrito(Product producto){
        productosEnCarrito.remove(producto);
    }
    
    
    
}
