/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.com.hyunseda.market.service;

import infra.Subject;

/**
 *
 * @author Juan
 */
public class Venta extends Subject {
    private int id;
    private String descripcion;
    private int cantidad;
    private double precio;
    private double importe;
    
    
    public Venta() {
    }

    public Venta(int id, String descripcion, int cantidad, double precio, double importe) {
        this.id = id;
        this.descripcion = descripcion;
        this.cantidad = cantidad;
        this.precio = precio;
        this.importe = importe;
    }
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
        this.notifyAllObserves();
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getCantidad() {
        return cantidad;
        
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
        //this.notifyAllObserves();
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public double getImporte() {
        return importe;
    }

    public void setImporte(double importe) {
        this.importe = importe;
    }

    
}
