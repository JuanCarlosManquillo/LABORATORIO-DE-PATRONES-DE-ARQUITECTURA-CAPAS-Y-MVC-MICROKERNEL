
package co.com.hyunseda.market.presentation;

import co.com.hyunseda.market.service.Carrito;
import persistent.CategoryRepository;
import co.com.hyunseda.market.service.CategoryService;

import co.com.hyunseda.market.service.ICategoryService;
import persistent.IProductRepository;
import co.com.hyunseda.market.service.IProductService;
import co.com.hyunseda.market.service.Product;
import persistent.ProductRepository;
import co.com.hyunseda.market.service.ProductService;
import persistent.ICategoryRepository;

/**
 *
 * @author Libardo Pantoja
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
  
        
        IProductRepository ProdRepository = new ProductRepository();
        IProductService productService = new ProductService(ProdRepository);

       
        //Mostrando GUI de Categorias
        ICategoryRepository CatRepository = new CategoryRepository();
        ICategoryService categoryService = new CategoryService(CatRepository);
    
        GUIInicio inicio=new GUIInicio(productService, categoryService);
        inicio.setVisible(true);
      
        
        //GUICarrito carrito=new GUICarrito(productService);
        //carrito.setVisible(true);


    }
    
}
