package co.com.hyunseda.market.service;

/**
 *
 * @author Libardo Pantoja, Julio A. Hurtado
 */
class User {
    private Long userId;
    private String firstName;
    private String lastName;
    //Demas atributos

}
