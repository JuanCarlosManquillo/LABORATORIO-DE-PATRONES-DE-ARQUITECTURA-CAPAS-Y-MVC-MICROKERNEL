# lab2024-market
El código de un pequeño programa que almacena productos y que viola varios de los principios SOLID para ser refactorizada como parte del Laboratorio de Ingeniería de Software II en la Universidad del Cauca
